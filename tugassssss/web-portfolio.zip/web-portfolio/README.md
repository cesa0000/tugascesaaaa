# Web Portfolio (React + Vite + Bootstrap)

Aplikasi web dengan tiga halaman: Home, Team, dan Contact.

## Menjalankan proyek
```bash
npm install
npm run dev
```

## Teknologi
React 18, Vite, React Router, Bootstrap 5
