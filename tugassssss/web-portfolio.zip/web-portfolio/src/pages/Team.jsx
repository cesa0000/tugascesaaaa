const anggota = [
  { nama: "Nama Anggota 1", peran: "Frontend Developer", foto: "/img/avatar1.svg", deskripsi: "Menyukai desain antarmuka yang bersih dan mudah digunakan." },
  { nama: "Nama Anggota 2", peran: "UI/UX Designer", foto: "/img/avatar2.svg", deskripsi: "Merancang pengalaman pengguna yang menyenangkan." },
  { nama: "Nama Anggota 3", peran: "Backend Developer", foto: "/img/avatar3.svg", deskripsi: "Fokus membangun API yang cepat dan aman." },
  { nama: "Nama Anggota 4", peran: "Project Manager", foto: "/img/avatar4.svg", deskripsi: "Memastikan proyek berjalan tepat waktu dan terarah." },
];

function Team() {
  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold">Tim Kami</h1>
        <p className="text-muted">Orang-orang di balik proyek ini.</p>
      </div>

      <div className="row g-4">
        {anggota.map((a) => (
          <div className="col-sm-6 col-lg-3" key={a.nama}>
            <div className="card team-card h-100 border-0 shadow-sm text-center p-3">
              <img src={a.foto} alt={a.nama} className="mx-auto mt-3" />
              <div className="card-body">
                <h5 className="card-title fw-bold mb-1">{a.nama}</h5>
                <span className="badge bg-primary mb-3">{a.peran}</span>
                <p className="card-text text-muted small">{a.deskripsi}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Team;
