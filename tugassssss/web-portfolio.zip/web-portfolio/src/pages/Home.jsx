import { Link } from "react-router-dom";

const fitur = [
  { ikon: "⚡", judul: "Cepat", teks: "Dibangun dengan Vite sehingga proses pengembangan dan build berjalan sangat cepat." },
  { ikon: "🧩", judul: "Berbasis Komponen", teks: "Tampilan dipecah menjadi komponen React yang rapi dan dapat dipakai ulang." },
  { ikon: "📱", judul: "Responsif", teks: "Menggunakan Bootstrap sehingga tampilan menyesuaikan layar HP, tablet, dan komputer." },
];

function Home() {
  return (
    <>
      <section className="hero py-5">
        <div className="container py-4">
          <div className="row align-items-center g-4">
            <div className="col-lg-6">
              <h1 className="display-4 fw-bold">Selamat Datang di Web Portfolio Kami</h1>
              <p className="lead my-4">
                Kami adalah tim yang suka membangun aplikasi web modern yang sederhana,
                cepat, dan nyaman digunakan.
              </p>
              <Link to="/team" className="btn btn-light btn-lg me-2">Kenali Tim</Link>
              <Link to="/contact" className="btn btn-outline-light btn-lg">Hubungi Kami</Link>
            </div>
            <div className="col-lg-6 text-center">
              <img src="/img/hero.svg" alt="Ilustrasi pengembangan web" className="img-fluid" style={{ maxHeight: 320 }} />
            </div>
          </div>
        </div>
      </section>

      <section className="container py-5">
        <h2 className="text-center fw-bold mb-5">Kenapa Memilih Kami?</h2>
        <div className="row g-4">
          {fitur.map((item) => (
            <div className="col-md-4" key={item.judul}>
              <div className="card h-100 border-0 shadow-sm text-center p-3">
                <div className="card-body">
                  <div className="feature-icon mb-3">{item.ikon}</div>
                  <h5 className="card-title fw-bold">{item.judul}</h5>
                  <p className="card-text text-muted">{item.teks}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="container">
        <div className="bg-light rounded-4 p-5 text-center">
          <h3 className="fw-bold">Siap berkolaborasi?</h3>
          <p className="text-muted">Ceritakan idemu dan mari kita wujudkan bersama.</p>
          <Link to="/contact" className="btn btn-primary btn-lg">Mulai Sekarang</Link>
        </div>
      </section>
    </>
  );
}

export default Home;
