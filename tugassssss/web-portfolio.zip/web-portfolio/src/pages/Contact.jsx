import { useState } from "react";

function Contact() {
  const [form, setForm] = useState({ nama: "", email: "", pesan: "" });
  const [terkirim, setTerkirim] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    setTerkirim(true);
    setForm({ nama: "", email: "", pesan: "" });
  };

  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold">Hubungi Kami</h1>
        <p className="text-muted">Punya pertanyaan atau ide? Kirim pesan kepada kami.</p>
      </div>

      <div className="row g-5">
        <div className="col-lg-5">
          <h4 className="fw-bold mb-4">Informasi Kontak</h4>
          <p>📍 Yogyakarta, Indonesia</p>
          <p>📧 halo@webportfolio.id</p>
          <p>📞 +62 812-3456-7890</p>
          <p>🕘 Senin – Jumat, 09.00 – 17.00 WIB</p>
        </div>

        <div className="col-lg-7">
          <div className="card border-0 shadow-sm p-4">
            {terkirim && (
              <div className="alert alert-success" role="alert">
                Terima kasih! Pesanmu sudah terkirim.
              </div>
            )}
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="nama" className="form-label">Nama</label>
                <input id="nama" name="nama" type="text" className="form-control" value={form.nama} onChange={handleChange} required />
              </div>
              <div className="mb-3">
                <label htmlFor="email" className="form-label">Email</label>
                <input id="email" name="email" type="email" className="form-control" value={form.email} onChange={handleChange} required />
              </div>
              <div className="mb-3">
                <label htmlFor="pesan" className="form-label">Pesan</label>
                <textarea id="pesan" name="pesan" rows="5" className="form-control" value={form.pesan} onChange={handleChange} required></textarea>
              </div>
              <button type="submit" className="btn btn-primary">Kirim Pesan</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Contact;
