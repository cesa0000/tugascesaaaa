function Footer() {
  return (
    <footer className="bg-dark text-white-50 py-4 mt-5">
      <div className="container text-center">
        <small>© {new Date().getFullYear()} Web Portfolio. Dibuat dengan React, Vite, dan Bootstrap.</small>
      </div>
    </footer>
  );
}

export default Footer;
